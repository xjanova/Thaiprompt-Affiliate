function Nav() {
  const [open, setOpen] = React.useState(false);
  return (
    <header className="nav">
      <div className="container nav-inner">
        <div className="brand">
          <div className="brand-mark">TP</div>
          <div className="brand-text">
            <strong>ThaiPrompt <span style={{color:'var(--gold-500)', fontWeight:700}}>ไทยพร๊อมท์</span></strong>
            <span>POS · Blockchain · AI Management</span>
          </div>
        </div>
        <nav className="nav-links">
          <a href="#" className="active">หน้าแรก</a>
          <a href="#services">บริการ</a>
          <a href="#wallet">Wallet</a>
          <a href="#how">วิธีใช้งาน</a>
          <a href="#asia">เครือข่าย</a>
          <a href="#contact">ติดต่อ</a>
        </nav>
        <div className="nav-cta">
          <button className="btn btn-ghost btn-sm">เข้าสู่ระบบ</button>
          <button className="btn btn-primary btn-sm">
            สมัครสมาชิก <Ico.arrow style={{width:14,height:14}}/>
          </button>
        </div>
      </div>
    </header>
  );
}
window.Nav = Nav;
