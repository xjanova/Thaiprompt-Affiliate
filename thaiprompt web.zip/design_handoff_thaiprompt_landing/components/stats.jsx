function Ticker() {
  const items = [
    { em: '⚡', t: 'Block #2,481,902 confirmed' },
    { em: '✦', t: '+12,408 transactions today' },
    { em: '◈', t: 'Avg fee 0.0008 TPX' },
    { em: '◆', t: 'Network uptime 99.98%' },
    { em: '✸', t: 'Active validators 142' },
    { em: '⬢', t: 'Cross-Asia payments enabled' },
  ];
  const list = [...items, ...items];
  return (
    <div className="ticker">
      <div className="ticker-track">
        {list.map((x, i) => (
          <span key={i} className="ticker-item">
            <span className="em">{x.em}</span> {x.t}
            <span className="ticker-dot" style={{marginLeft: 24}}></span>
          </span>
        ))}
      </div>
    </div>
  );
}
window.Ticker = Ticker;
