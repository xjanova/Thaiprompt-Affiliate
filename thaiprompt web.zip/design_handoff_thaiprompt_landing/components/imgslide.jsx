function ImgSlide({ image, fade = 'dark', focal = 'center', fullscreen = false, animate = true }) {
  const fadeClass = fade === 'light' ? ' fade-light' : (fade === 'asia' ? ' fade-asia' : '');
  const cls = "imgslide" + fadeClass + (fullscreen ? ' fullscreen' : '') + (animate ? ' animate' : '');
  return (
    <section className={cls}>
      <div className="imgslide-bg" style={{backgroundImage: `url(${image})`, backgroundPosition: focal}}/>
      {animate && <div className="imgslide-decor"><span/><span/><span/><span/><span/></div>}
    </section>
  );
}
window.ImgSlide = ImgSlide;
