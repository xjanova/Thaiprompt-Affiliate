const SERVICES = [
  {
    tag: 'Rider & Delivery',
    title: 'ไรเดอร์ & อีคอมเมิร์ซ',
    desc: 'ส่งไว ปลอดภัย ครอบคลุมทั่วไทยและเอเชีย ด้วยระบบจัดเส้นทางอัจฉริยะ',
    feats: ['ติดตามแบบ real-time', 'ค่าส่งโปร่งใส', 'รองรับร้านค้านับพัน'],
    icon: 'rider',
    accent: 'linear-gradient(135deg,#ff7a2d,#d04b00)',
    shadow: 'rgba(255,122,45,.45)',
  },
  {
    tag: 'Fresh Market',
    title: 'ตลาดสดออนไลน์',
    desc: 'ของสดคุณภาพดี ราคายุติธรรม จากเกษตรกรและพ่อค้าแม่ค้าตัวจริง',
    feats: ['ของสดวันต่อวัน', 'ราคาจากต้นทาง', 'ส่งถึงบ้าน'],
    icon: 'market',
    accent: 'linear-gradient(135deg,#22c55e,#0e7e3a)',
    shadow: 'rgba(34,197,94,.45)',
  },
  {
    tag: 'AI Management',
    title: 'จัดการด้วย AI',
    desc: 'AI ช่วยวิเคราะห์ยอดขาย วางแผนสต็อก แม่นยำ เพิ่มประสิทธิภาพร้านค้าของคุณ',
    feats: ['Forecast ยอดขาย', 'จัดการสต็อกอัตโนมัติ', 'แชทบอทตอบลูกค้า'],
    icon: 'ai',
    accent: 'linear-gradient(135deg,#3d82ff,#0a3aac)',
    shadow: 'rgba(11,76,219,.5)',
  },
  {
    tag: 'Digital Wallet',
    title: 'กระเป๋าเงินดิจิทัล',
    desc: 'จ่าย รับ โอน ค่าธรรมเนียมต่ำ ปลอดภัยด้วย encryption ระดับธนาคาร',
    feats: ['โอนทันที 24/7', 'ค่าธรรมเนียมต่ำ', 'รองรับหลายสกุลเงิน'],
    icon: 'wallet',
    accent: 'linear-gradient(135deg,#f5b423,#a86c0d)',
    shadow: 'rgba(245,180,35,.45)',
  },
  {
    tag: 'Dividend System',
    title: 'ระบบปันผลโปร่งใส',
    desc: 'แบ่งผลประโยชน์อย่างเป็นธรรม ตรวจสอบได้ทุกธุรกรรม บนเชนของเราเอง',
    feats: ['Smart contract ปันผลอัตโนมัติ', 'ตรวจสอบบนเชนได้', 'ทุกบาทมีที่มาที่ไป'],
    icon: 'dividend',
    accent: 'linear-gradient(135deg,#a855f7,#5b21b6)',
    shadow: 'rgba(168,85,247,.45)',
  },
  {
    tag: 'ThaiPrompt Chain',
    title: 'Blockchain ของเราเอง',
    desc: 'เครือข่ายของคนไทย เพื่อคนไทย รองรับ smart contract และ payment ขนาดใหญ่',
    feats: ['Public chain ของไทย', 'Throughput สูง ค่า gas ต่ำ', 'นักพัฒนาเข้าถึงง่าย'],
    icon: 'chain',
    accent: 'linear-gradient(135deg,#06b6d4,#0a3aac)',
    shadow: 'rgba(6,182,212,.45)',
  },
];

function Services() {
  return (
    <section id="services" className="services fade-top-light fade-bottom-light">
      <div className="container">
        <div className="sec-head">
          <div className="eyebrow">หกเสาหลักของเรา</div>
          <h2>แพลตฟอร์มเดียว <span className="grad">รวมทุกโซลูชัน</span></h2>
          <p>เชื่อมร้านค้า ผู้บริโภค ไรเดอร์ และเครือข่ายปันผล เข้าด้วยกันบนระบบเดียว ที่โปร่งใส ยุติธรรม และเติบโตไปด้วยกัน</p>
        </div>

        <div className="services-grid">
          {SERVICES.map((s, i) => {
            const I = Ico[s.icon];
            return (
              <article
                key={i}
                className="service-card"
                style={{
                  '--accent': s.accent,
                  '--accent-shadow': s.shadow,
                }}
              >
                <div className="ic"><I style={{width:26,height:26}}/></div>
                <span className="tag">{s.tag}</span>
                <h3>{s.title}</h3>
                <p>{s.desc}</p>
                <ul className="feats">
                  {s.feats.map((f, j) => (
                    <li key={j}><Ico.check/> {f}</li>
                  ))}
                </ul>
                <div className="arrow">เรียนรู้เพิ่มเติม <Ico.arrow style={{width:14,height:14}}/></div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
window.Services = Services;
