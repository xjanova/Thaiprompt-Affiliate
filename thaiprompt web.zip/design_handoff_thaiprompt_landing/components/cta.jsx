function CTA() {
  const [email, setEmail] = React.useState('');
  const [sent, setSent] = React.useState(false);
  return (
    <section id="contact" style={{padding:'48px 0 96px'}}>
      <div className="container">
        <div className="cta-strip">
          <div>
            <div className="eyebrow" style={{color:'#ffe28a'}}>โหลดเลย — ฟรี</div>
            <h2 style={{marginTop:12}}>เริ่มต้น <span className="gold">อนาคตที่ดีกว่า</span><br/>กับ ThaiPrompt วันนี้</h2>
            <p>โปร่งใส · ยุติธรรม · เติบโตไปด้วยกัน — แพลตฟอร์มเดียวที่รวมทุกบริการ
              พร้อมระบบปันผลที่ตรวจสอบได้บน Blockchain ของเราเอง</p>
            <div style={{display:'flex', gap:12, flexWrap:'wrap'}}>
              <button className="btn btn-gold">ดาวน์โหลดแอป <Ico.arrow style={{width:14,height:14}}/></button>
              <button className="btn btn-outline-white">เป็นร้านค้าพาร์ทเนอร์</button>
            </div>
          </div>

          <form className="cta-form" onSubmit={(e) => { e.preventDefault(); setSent(true); }}>
            <label>รับข่าวสารและสิทธิพิเศษก่อนใคร</label>
            <div className="cta-form-row">
              <input
                type="email"
                placeholder="กรอกอีเมลของคุณ"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <button className="btn btn-gold" type="submit">
                {sent ? 'รับแล้ว ✓' : 'สมัครรับข่าว'}
              </button>
            </div>
            <div className="hint">เราเคารพความเป็นส่วนตัว ยกเลิกได้ทุกเมื่อ</div>
          </form>
        </div>
      </div>
    </section>
  );
}
window.CTA = CTA;
