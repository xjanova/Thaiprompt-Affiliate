# Handoff: ThaiPrompt — Landing Page Redesign

## Overview

A redesigned public landing page for **ThaiPrompt (ไทยพร๊อมท์)** — a Thai-first all-in-one platform that
combines Rider/Delivery, E-commerce, Fresh Market, AI Management, Digital Wallet, Dividend system and a
proprietary Blockchain. The page introduces the brand, walks visitors through the six service pillars,
showcases the Wallet/Blockchain product, explains how to get started, and highlights the platform's
Asia-wide ambition.

Audience: Thai consumers, merchants, riders, partners, and developers.
Tone: warm, confident, slightly promotional — Thai-first with English tech terms.
Visual DNA: deep navy + gold luxury palette, full-bleed brand imagery as section dividers, smooth fades
between sections, subtle animation, mobile-first responsive.

## About the Design Files

The files in this bundle are **design references created in HTML/JSX** — interactive prototypes
demonstrating intended look, layout, copy, motion, and behavior. They are **not production code to ship
as-is**.

The task for the implementing developer is to **recreate these designs in the target codebase's existing
environment** (the live site is Laravel 11 + Blade + Tailwind v4 + Alpine.js per project context — but
this can also be implemented in React/Next, Vue/Nuxt, or any other framework). Use the codebase's
established patterns, component library, typography, and build pipeline.

If no production environment exists yet, **Next.js (App Router) + Tailwind CSS** is recommended because:

1. The design relies heavily on layered backgrounds, gradients, and `clamp()` typography — Tailwind v4
   handles all of this natively.
2. The hero stat-strip overlap and image-slide section transitions need precise control over stacking
   contexts; React component composition makes that maintainable.
3. The page is content-heavy and SEO-relevant; SSR/SSG matters.

## Fidelity

**High-fidelity.** All colors, typography, spacing, radii, shadows, animations, and copy in the prototype
are intended as final unless explicitly flagged below. Recreate the UI pixel-perfectly using the target
codebase's libraries; the only allowed deviations are:

- Substituting the codebase's icon system if it has one (the prototype uses inline SVG Heroicons-style).
- Using the codebase's button / form-input components if present, as long as visual output matches.
- Replacing the placeholder hero/banner illustrations with final brand imagery from the design team
  (the prototype crops out QR codes and bottom URL bars from supplied artwork).

## Page Structure

The page is a single scrolling document. Sections in order:

1. `<Nav>` — sticky top navigation
2. `<ImgSlide>` — **Slide 1**: full-bleed hero image, no text overlay, no animation, fades into Hero
3. `<Hero>` — heading, value props, CTAs, floating product cards, and the `.hero-stats` strip
4. `<Ticker>` — animated marquee of blockchain status pills
5. `<Services>` — six service pillar cards
6. `<ImgSlide>` — **Slide 2**: temple/brand image, animated, fades into Wallet
7. `<Wallet>` — Wallet feature grid + interactive phone mockup
8. `<HowItWorks>` — 4-step onboarding
9. `<ImgSlide>` — **Slide 3**: ecosystem flow image, animated, fades into Asia
10. `<Asia>` — Asia network map + country flags
11. `<CTA>` — newsletter form + final CTA
12. `<Footer>` — links + social

---

## Design Tokens

All values are CSS custom properties on `:root` in `styles.css`. Recreate as Tailwind theme extension or
your codebase's token system.

### Colors

```
/* Brand backgrounds (deep navy ramp) */
--bg-deep:  #050b1a   /* page edges, footer, hero base */
--bg-1:     #0a1430
--bg-2:     #0e1c4a
--bg-3:     #122769

/* Primary blue ramp */
--blue-50:  #eaf2ff
--blue-100: #cfe0ff
--blue-200: #9dc0ff
--blue-300: #6aa0ff
--blue-400: #3d82ff
--blue-500: #1f64ff   /* primary action */
--blue-600: #0b4cdb
--blue-700: #0a3aac
--blue-800: #082b7f

/* Gold ramp (accent — used for highlights, CTAs, headlines) */
--gold-300: #ffe28a
--gold-400: #ffcd54
--gold-500: #f5b423
--gold-600: #d99318
--gold-700: #a86c0d

/* Supporting hues */
--teal:     #38d3ee
--cyan:     #6ee7ff
--orange:   #ff7a2d

/* Ink (text on light) */
--ink:      #0a1230   /* headlines */
--ink-2:    #2a3760   /* body */
--ink-3:    #5b6890   /* muted */
--line:     rgba(20, 50, 120, .12)

/* Page background (light sections) */
--page-light: #fafbff
```

### Signature gradients

```
/* Headline gold gradient */
linear-gradient(180deg, #fff2c2 0%, #ffcd54 45%, #d99318 100%)

/* Headline blue gradient */
linear-gradient(180deg, #cfe0ff, #6aa0ff 60%, #3d82ff)

/* Primary button */
linear-gradient(135deg, #1f64ff, #0a3aac)

/* Gold button */
linear-gradient(135deg, #ffd76a, #f5b423)

/* Brand mark */
linear-gradient(135deg, #0b4cdb, #082b7f 70%)

/* Accent text gradient (used in section heads with .grad class) */
linear-gradient(90deg, #0b4cdb, #f5b423)
```

### Typography

- **Display / Headlines:** `Prompt`, weights 500–900 — used for h1/h2/h3 and brand wordmark
- **Body:** `Noto Sans Thai`, weights 300–700 — fallback `Inter`, system stack
- Loaded via Google Fonts:
  ```
  https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@300;400;500;600;700;900&family=Inter:wght@400;500;600;700;800;900&family=Prompt:wght@500;600;700;800;900&display=swap
  ```

Type scale (use `clamp()` for fluid sizing):

| Role | Size | Weight | Line-height | Letter-spacing |
|---|---|---|---|---|
| Hero h1 | `clamp(40px, 6vw, 78px)` | 800 | 1.02 | -.02em |
| Slide eyebrow | 12px | 600 | normal | .12em uppercase |
| Section h2 | `clamp(30px, 4vw, 48px)` | 800 | 1.1 | -.02em |
| Card h3 | 19px | 700 | snug | normal |
| Body lg | 17px | 400 | 1.6 | normal |
| Body | 15px | 400 | 1.6 | normal |
| Small/meta | 13px | 500 | 1.5 | normal |
| Eyebrow | 12px | 700 | normal | .18em uppercase |

### Spacing

Tailwind-aligned scale: 4 / 8 / 12 / 16 / 20 / 24 / 32 / 40 / 48 / 64 / 80 / 96 px.
Section vertical padding: `96px` desktop → `64px` ≤900px → `56px` ≤540px.
Container: `max-width: 1280px; padding: 0 24px; margin: 0 auto`.

### Radii

```
6px   --r-sm    (small badges)
10px  --r-md    (chips, pills)
14px  --r-md    (icon chips inside cards)
20px  --r-lg    (form inputs, balance card)
28px  --r-xl    (image-slide map card)
36px  --r-2xl   (CTA strip)
9999  --r-full  (pills, avatars, dots)
```

### Shadows

```
--shadow-card:  0 18px 40px -22px rgba(8,30,90,.35), 0 4px 14px -6px rgba(8,30,90,.15)
--shadow-glow:  0 30px 80px -30px rgba(31,100,255,.55)

/* Per-context glows */
shadow-glow-blue: 0 10px 24px -10px rgba(11,76,219,.55)
shadow-glow-gold: 0 10px 24px -10px rgba(245,180,35,.55)
```

### Easing & duration

- Standard: `cubic-bezier(.4, 0, .2, 1)` 200/300/500ms
- Reveal slide-up: `cubic-bezier(.2, .7, .2, 1)` 800–1000ms with stagger
- Floating elements: `5s ease-in-out infinite` Y-axis 10px
- Ticker: `35s linear infinite`
- Ken Burns: `16s ease-in-out infinite alternate` (only on `.imgslide.animate`)

---

## Components

### `<Nav>` — Sticky header

- Position: `sticky; top: 0; z-index: 50`
- Background: `rgba(255,255,255,.78)` with `backdrop-filter: blur(18px) saturate(150%)`
- Border-bottom: `1px solid rgba(20,50,120,.08)`
- Inner: `display: flex; justify-content: space-between; padding: 14px 0` inside `.container`
- **Brand mark**: 40×40 `rounded-12px` square, gradient `135deg #0b4cdb→#082b7f`, gold "TP" wordmark
  in 'Prompt' 900 20px, `inset shadow + drop shadow`
- **Brand text**: stacked — bold "ThaiPrompt ไทยพร๊อมท์" (gold accent on Thai) + 11px subtitle
- **Links** (28px gap): หน้าแรก / บริการ / Wallet / วิธีใช้งาน / เครือข่าย / ติดต่อ — 14px / 500
  weight / `--ink-2`. Active state has 2px gradient underline `gold-500 → blue-500`.
- **CTA group**: ghost "เข้าสู่ระบบ" + primary "สมัครสมาชิก" with arrow
- **Responsive**: hide nav links below 900px (mobile menu drawer not specified — implement standard
  hamburger pattern). Hide ghost login button below 640px. Hide brand subtitle below 640px.

### `<ImgSlide>` — Image section divider

A reusable full-bleed image section. Props:

```ts
interface ImgSlideProps {
  image: string;           // URL
  fade?: 'dark' | 'light' | 'asia';   // matches color of NEXT section
  focal?: string;          // CSS background-position (default 'center')
  fullscreen?: boolean;    // 100vh, min-height 560px
  animate?: boolean;       // Ken Burns + sparkles
}
```

- Default height: `clamp(440px, 64vh, 760px)`
- `fullscreen`: `100vh; min-height: 560px`
- Background image: cover, positioned via `focal` prop
- **Bottom fade overlay** (`::after`) — 55% height linear gradient that ends at the EXACT bg color of
  the next section. This is critical for seamless transitions:
  - `fade="dark"` ends at `#050b1a` — use before Hero, Wallet, Footer
  - `fade="light"` / `fade="asia"` ends at `#fafbff` — use before Asia, Services, How
- **Top vignette** (`::before`): radial darkening 70%×60% from center
- **Animation** (`animate=true`):
  - Background scales 1.05→1.12 with -1.5% / -1% drift (Ken Burns), 16s alternate
  - 5 floating sparkle dots (3 gold, 2 cyan), 6px diameter with 14px glow, animated up/down 5s
- `margin-bottom: -1px` on slide and `margin-top: -1px` on the next section to kill subpixel edges.

Three slides used:

| # | Image | fullscreen | animate | fade | Next section |
|---|---|---|---|---|---|
| 1 | `slide-top.png` | ✓ | ✗ | dark | Hero (#050b1a) |
| 2 | `slide-temple.png` | — | ✓ | dark | Wallet (#050b1a → #0a1742) |
| 3 | `slide-flow.png` | — | ✓ | light | Asia (#fafbff) |

### `<Hero>`

Layout: 2-column grid `1.1fr 1fr`, gap 56px, padding-block 72px/96px (collapses to 1col below 980px).

**Background** (layered):
```
radial-gradient(1200px 700px at 80% -10%, rgba(31,100,255,.45), transparent 60%),
radial-gradient(900px 600px at 0% 100%, rgba(245,180,35,.18), transparent 60%),
linear-gradient(180deg, #050b1a 0%, #081231 60%, #0a1742 100%)
```
Plus a fading 56px CSS grid overlay (`rgba(110,231,255,.08)` lines, masked to fade at edges) and a star
field of radial-gradient pixel dots that twinkle 6s alternate.

**Left column:**
- **Eyebrow pill** (rounded-full, .06 white bg, gold-tinted border): green pulsing dot + "แพลตฟอร์มคนไทย • เพื่อคนไทย • เพื่อเอเชีย"
- **H1** two lines:
  - Line 1: gold-gradient "ไทยพร๊อมท์" + white "แพลตฟอร์ม"
  - Line 2: blue-gradient "เพื่อชีวิตที่ดีกว่า"
- **Sub** (rgba .78 white): "รวมทุกโซลูชันในที่เดียว — Rider & E-commerce, ตลาดสด, AI Management, กระเป๋าเงินดิจิทัล และระบบปันผลที่โปร่งใสด้วย Blockchain ของเราเอง"
- **Pillar chips** (4): โปร่งใส / ยุติธรรม / เติบโตไปด้วยกัน / ยั่งยืน — gold sparkle icon
- **CTAs**: gold "เริ่มต้นใช้งานฟรี" + outline-white "ดูวิธีการทำงาน"
- **Meta strip**: 10+ ประเทศ / 50K+ ผู้ใช้งาน / 24/7 ตลอดเวลา

**Right column** (.hero-visual, 540px tall):
- **Hero card**: rounded-28px, bg image `assets/hero-rider.png`, gradient overlay, top-left gold pill
  badge "แพลตฟอร์มคนไทย เพื่อคนไทย" + bottom-right glass pill "โปร่งใส · ตรวจสอบได้ด้วย Blockchain"
- **3 floating cards** (white, blur backdrop, 16px radius, animated `floatY` 4.5s with stagger):
  1. ออเดอร์วันนี้ — `+2,481 ↑12%` — orange icon (rider)
  2. ปันผลรายสัปดาห์ — `฿ 84,250` — gold icon (wallet)
  3. ธุรกรรมบนเชน — `1.2M+ TX` — cyan icon (chain)

**`.hero-stats` strip** — overlaps hero by `-56px`, `z-index: 6`:
- White, `rounded-24px`, `max-width: 1180px`, 4-column grid
- Each cell: 44×44 light blue icon chip + big number (Prompt 800 30px blue-700) + 13px muted label
- Counts: 50K+ ผู้ใช้งาน / 2.4M+ ออเดอร์ / 99.9% เสถียรภาพ / 10+ ประเทศ
- Responsive: 4col → 2col ≤900px → 1col ≤540px

### `<Ticker>`

Marquee bar between hero and services.
- Background: `linear-gradient(90deg, #082b7f, #0a3aac, #082b7f)` with gold .25 borders top/bottom
- Items duplicated for seamless loop, 56px gap, 35s linear infinite scroll
- Items contain glyph (`⚡✦◈◆✸⬢`) in gold + 14px bold white label + gold dot separator
- Sample content: "Block #2,481,902 confirmed" / "+12,408 transactions today" /
  "Avg fee 0.0008 TPX" / "Network uptime 99.98%" / "Active validators 142" / "Cross-Asia payments enabled"

### `<Services>`

3-column grid (→ 2col ≤980px → 1col ≤640px), gap 20px, on `#fafbff` background.

Section head pattern (reused throughout):
- Gold eyebrow with 24px hairline `::before` — "หกเสาหลักของเรา"
- H2 "แพลตฟอร์มเดียว <span class='grad'>รวมทุกโซลูชัน</span>"
- 17px muted lead

**Card structure** (white, `rounded-24px`, 28px×26px padding, 1px line border):

```
[ 56×56 icon chip — gradient bg + colored shadow ]
TAG (12px uppercase letterspaced blue-600)
H3 (Prompt 700 19px)
Description (14px muted)
✓ feature 1   ← gold check + 13px ink
✓ feature 2
✓ feature 3
"เรียนรู้เพิ่มเติม →" (blue-600 600 weight, arrow translates on hover)
```

Hover: `translateY(-6px)` + shadow-card + border transparent. 350ms.

The 6 services with exact gradient + content (see `components/services.jsx` for source):

| # | Tag | Title | Icon | Gradient |
|---|---|---|---|---|
| 1 | Rider & Delivery | ไรเดอร์ & อีคอมเมิร์ซ | rider | orange (`#ff7a2d→#d04b00`) |
| 2 | Fresh Market | ตลาดสดออนไลน์ | market | green (`#22c55e→#0e7e3a`) |
| 3 | AI Management | จัดการด้วย AI | ai (chip grid) | blue (`#3d82ff→#0a3aac`) |
| 4 | Digital Wallet | กระเป๋าเงินดิจิทัล | wallet | gold (`#f5b423→#a86c0d`) |
| 5 | Dividend System | ระบบปันผลโปร่งใส | dividend (pie) | purple (`#a855f7→#5b21b6`) |
| 6 | ThaiPrompt Chain | Blockchain ของเราเอง | chain | cyan (`#06b6d4→#0a3aac`) |

### `<Wallet>` — Phone mockup showcase

2-column grid `1fr 1.1fr` (collapses ≤980px), gap 64px.

Background (layered): `linear-gradient(180deg, #050b1a 0%, #060d22 8%, #0a1742 100%)` + radial blue glow
top-right + radial gold glow bottom-left + 48px grid overlay + ellipse mask.

**Left column:**
- Gold eyebrow "ThaiPrompt Wallet"
- H2 "กระเป๋าเงินดิจิทัล <span class='gold'>ปลอดภัย โปร่งใส</span>"
- Lead paragraph
- **2×2 feature grid** (`.wallet-feat`): each is a glass card (`rgba(255,255,255,.04)` bg, .08 border,
  `rounded-16px`, 18px padding, blur). 38px gold icon chip with cyan border + 15px Prompt h4 +
  13px .6-opacity body. Hover: gold border + lift.
  - 🛡 เข้ารหัสระดับธนาคาร — multi-signature + cold storage
  - ⚡ โอนทันที 24/7 — ยืนยันในไม่กี่วินาที ข้ามประเทศ
  - 💸 รับปันผลอัตโนมัติ — Smart contract กระจายผลประโยชน์
  - 🌐 ใช้ได้ทั่วเอเชีย — รองรับหลายสกุลเงิน
- CTAs: gold "เปิดกระเป๋า TPX" + outline-white "ดู Whitepaper"

**Right column (.phone-mock):** square 1:1 grid centered.
- Two dashed orbit rings (cyan + gold), counter-rotating 30/40s
- 3 gold coins floating with stagger ("฿", "TP", "$"), 64/52/44px
- **Phone**: 280×560 black bezel (`rounded-44px`, layered insets simulating frame), centered notch
- **Phone screen** (rounded-36px, 22px×18px padding, navy gradient):
  - Header: "สวัสดี, คุณสมชาย" + green "Live" with pulsing dot
  - **Balance card**: blue gradient bg, gold radial glow top-right, "ยอดคงเหลือทั้งหมด" / Prompt 800
    28px "฿ 128,540.25" / pill "↑ +5.2% สัปดาห์นี้"
  - **4 action buttons** (grid): ส่ง / รับ / สลับ / สแกน — gold icons
  - **3 transaction rows** (glass): ปันผลรายสัปดาห์ +฿1,840 (green) / ตลาดสด รังสิต -฿285 (red) /
    Stake TPX +12.4 TPX (green)

### `<HowItWorks>`

4-step horizontal track on `#fafbff`. Steps connected by a dotted blue line (`::before` overlay) at top
of the number circles. Below 900px stacks 2col then 1col, line removed.

Each step:
- 72×72 white square `rounded-24px` with subtle inset/outer shadow, big "1/2/3/4" in Prompt 800 28px
  blue-700. On hover: gradient gold→blue glow ring `inset(-6px)` at .25 opacity
- H4 "Prompt 700 17px"
- 14px muted body 1.6 line height

Steps (Thai):
1. สมัครสมาชิก — สร้างบัญชีฟรี ยืนยัน KYC
2. เชื่อมต่อบริการ — เลือก Rider/ตลาด/Wallet/พาร์ทเนอร์
3. เริ่มใช้งานทันที — ซื้อขายโอนส่ง จัดการร้านในแอปเดียว
4. รับปันผล & เติบโต — Smart contract ทุกสัปดาห์

### `<Asia>` — Network map

2-column grid `1fr 1.2fr`, on light background.

**Left column**: eyebrow "เครือข่ายเอเชีย" + h2 "เพื่อคนไทย <span class='grad'>เพื่อเอเชีย</span>
เพื่ออนาคตที่ดีกว่า" + body + flag pills + primary "เป็นพาร์ทเนอร์กับเรา" CTA.

12 flag pills (`.flag-pill` — white bg, line border, 14px/600 ink-2, 18px emoji): TH/VN/ID/PH/MY/SG/LA/MM/KH/CN/KR/JP

**Right column (`.asia-map`)** — 2:1 aspect ratio card with `<WorldMap>` SVG inside (1000×500 viewBox).

The map renders:
- Sea: `linear-gradient(#f0f5ff → #dbe7ff)`
- All other continents (NA, SA, EU, Africa, Australia, Greenland): `#cfe0ff → #9dc0ff` at 0.85 opacity
- **Asia highlighted**: blue gradient `#1f64ff → #0b4cdb → #082b7f` (Russia/China/Mongolia, India,
  Middle East, SE Asia mainland, Japan, Korea, Indonesia/Philippines island groups)
- **Gold radial glow** behind Asia (cx 720 cy 220 rx 240 ry 180, opacity .35)
- **6 dashed gold connection arcs** from Thailand (~725, 295) to: Japan, Korea, China, Indonesia,
  Philippines, India

Map pin overlay (12 absolute-positioned `.map-pin` divs):
- Each: 14×14 circle, blue-500 (`var(--blue-500)`) with two layered ring shadows
- Pulse animation 2.4s scale 1→1.25 with stagger
- Thailand pin uses `.gold` modifier (`var(--gold-500)`)
- Coordinates given as `top%/left%` calibrated for the 1000×500 map (see `components/asia.jsx`)

### `<CTA>`

Wraps in 96px section. The CTA strip itself is a card:
- `max-width: 1180px`, `padding: 64px clamp(24px, 5vw, 56px)`, `rounded-36px`
- Background: gold radial top-left + cyan radial bottom-right + `linear-gradient(135deg, #082b7f, #050b1a 70%)`
- 2-column grid `1.4fr 1fr` (collapses ≤900px)

Left:
- Gold eyebrow "โหลดเลย — ฟรี"
- H2 "เริ่มต้น <span class='gold'>อนาคตที่ดีกว่า</span> กับ ThaiPrompt วันนี้"
- Lead body
- CTAs: gold "ดาวน์โหลดแอป" + outline-white "เป็นร้านค้าพาร์ทเนอร์"

Right (`.cta-form`):
- Glass panel (`rgba(255,255,255,.06)` + .12 border, blur, `rounded-20px`, 22px padding)
- Label "รับข่าวสารและสิทธิพิเศษก่อนใคร"
- Email input (full-width, glass, `rounded-12px`) + gold submit button
- After submit: button text becomes "รับแล้ว ✓"
- Hint: "เราเคารพความเป็นส่วนตัว ยกเลิกได้ทุกเมื่อ"

### `<Footer>`

Dark `#050b1a` background, 72px top / 32px bottom padding.

4-column grid (`1.4fr 1fr 1fr 1fr`, collapses to 2col ≤900px → 1col ≤540px):

1. Brand block — 40×40 gold/blue brand mark, "ThaiPrompt ไทยพร๊อมท์" + tagline + mission line +
   4 social icons (Facebook, LINE, X, YouTube — inline SVG, 38×38 glass squares, hover: gold bg)
2. **บริการ** — Rider, ตลาดสด, AI Management, Wallet, ระบบปันผล
3. **นักพัฒนา** — Whitepaper, API Docs, Block Explorer, Smart Contract
4. **เกี่ยวกับเรา** — เกี่ยวกับ, ร่วมงาน, ติดต่อ, ข้อตกลง, นโยบายความเป็นส่วนตัว

Bottom bar: `border-top: rgba(255,255,255,.08)`, copyright + URL.

---

## Section Edge Fades

Adjacent same-tone sections use overlay gradients to soften their boundary:

```css
/* Light sections (#fafbff) */
.fade-top-light::before    { 60px linear from #fafbff to transparent }
.fade-bottom-light::after  { 80px linear from transparent to #fafbff }

/* Dark sections (#050b1a) */
.fade-bottom-dark::after   { 80px linear from transparent to #050b1a }
```

Applied to:
- `.services` — fade-top-light + fade-bottom-light
- `.how` — fade-top-light + fade-bottom-light
- `.asia` — fade-top-light + fade-bottom-light
- `.wallet-section` — fade-bottom-dark

`<ImgSlide>`'s built-in bottom gradient handles its own transition into the next section.

---

## Interactions & Behavior

| Element | Behavior |
|---|---|
| Service card hover | `translateY(-6px)` + colored shadow + border transparent (350ms) |
| Service card "เรียนรู้เพิ่มเติม" | Arrow gap grows from 6px to 10px on card hover |
| Wallet feature hover | Border becomes `rgba(255,205,84,.4)` + `translateY(-2px)` |
| Hero stat icons | No interaction — purely decorative |
| Floating product cards | Continuous Y-axis float (4.5s, staggered −1.4s, −2.6s) |
| Hero eyebrow dot | Pulsing green ring (1.8s) |
| Phone orbit rings | Counter-rotating 30s / 40s linear infinite |
| Phone coins | Float Y-axis 5s with stagger |
| Map pins | Pulse 2.4s with `${i*0.18}s` stagger across 12 pins |
| Ticker | Continuous 35s linear infinite (translate −50%) |
| Image slide (animated only) | Ken Burns 16s alternate + 5 sparkles 5s float |
| Newsletter form submit | `setSent(true)` swaps button label to "รับแล้ว ✓" — no actual API call wired |
| Reveal-on-scroll | `IntersectionObserver` adds `.in` class to elements with `.reveal` class. 0.1 threshold. (Currently no elements use this — hooks are wired in `app.jsx` for future use.) |

## State Management

Minimal local state:
- `<CTA>` — `email: string`, `sent: boolean` (newsletter form)
- `<Nav>` — `open: boolean` (currently unused; reserved for mobile drawer)

No global state, no data fetching. All counts are static placeholders. In production the
hero-stats numbers, ticker items, and map pin counts should be backed by an API.

## Responsive Behavior

| Breakpoint | Changes |
|---|---|
| ≤980px | Hero collapses to 1 column. Wallet collapses to 1 column. Services grid → 2 columns. |
| ≤900px | Sections shrink padding to 64px. Asia/CTA grids collapse to 1 column. How-it-works track → 2 columns (line removed). Footer → 2 columns. Nav links hidden (implement mobile menu). |
| ≤640px | Services grid → 1 column. Footer → 1 column. Hide ghost login button. Hide brand subtitle. |
| ≤540px | Sections shrink padding to 56px. Hero stats → 1 column. CTA strip padding shrinks. |

The site is built mobile-first in spirit but desktop-targeted in pixel sizing. Test at 375 / 414 / 768 /
1024 / 1280 / 1440 widths.

## Assets

| File | Source | Notes |
|---|---|---|
| `assets/slide-top.png` | Provided by user (Freepik AI) | Cropped bottom 14% to remove QR + URL bar |
| `assets/slide-temple.png` | Provided by user (Freepik AI) | Used as-is |
| `assets/slide-flow.png` | Provided by user (Freepik AI) | Used as-is |

Replace with final brand artwork before launch. The QR code visible in the original supplied images was
stripped per direction; if a QR code is needed in production, add it as a separate component (e.g. in
`<CTA>`), not baked into the imagery.

Icons are inline SVG, Heroicons-style outline (stroke 1.8, 24×24 viewBox). The full set is in
`components/icons.jsx` (`Ico.{rider, cart, market, ai, wallet, chain, dividend, shield, bolt, globe,
users, check, arrow, spark, send, qr, recv, swap, trend, star}`).

## Files in this bundle

```
design_handoff_thaiprompt_landing/
├── README.md                  ← this file
├── index.html                 ← entry point loading all components
├── styles.css                 ← all CSS (single file, ~31kb)
├── app.jsx                    ← root <App> with section composition
├── components/
│   ├── icons.jsx              ← Ico.* icon set
│   ├── nav.jsx
│   ├── hero.jsx
│   ├── imgslide.jsx           ← reusable image-section divider
│   ├── stats.jsx              ← <Ticker>
│   ├── services.jsx
│   ├── wallet.jsx
│   ├── howitworks.jsx
│   ├── asia.jsx               ← includes <WorldMap>
│   ├── cta.jsx
│   └── footer.jsx
└── assets/
    ├── slide-top.png
    ├── slide-temple.png
    └── slide-flow.png
```

The HTML loads React 18 + Babel standalone via CDN and uses `text/babel` script tags to transpile each
JSX file in the browser. **Production implementation should NOT use this approach** — compile JSX
ahead of time with the codebase's existing build system (Vite, Webpack, Next.js, etc.).

## Implementation Checklist for the Dev

- [ ] Set up project with Tailwind v4 (or migrate tokens to your CSS framework)
- [ ] Wire Google Fonts: Noto Sans Thai + Inter + Prompt
- [ ] Add CSS custom properties / Tailwind theme extension for all tokens listed above
- [ ] Implement section components in order from `app.jsx`
- [ ] Build the reusable `<ImgSlide>` with `fade` / `fullscreen` / `animate` variants
- [ ] Replace placeholder hero/stats/ticker data with real API endpoints
- [ ] Wire newsletter form to actual mailing-list backend
- [ ] Replace placeholder service-card "เรียนรู้เพิ่มเติม" links with real routes
- [ ] Add proper mobile menu drawer (currently nav links just hide ≤900px)
- [ ] Add footer link routes
- [ ] Add real social URLs
- [ ] Replace 3 image-slide artwork with final brand imagery (no QR codes baked in)
- [ ] Add SEO meta tags, OG image, structured data
- [ ] Add analytics, error tracking
- [ ] Verify accessibility: heading order, alt text on `<img>` (when added), focus-visible states,
      keyboard navigation, prefers-reduced-motion handling for Ken Burns + ticker + pulse animations
- [ ] Performance: lazy-load below-the-fold images, preload hero font, ensure CLS < 0.1

## Open Questions for Product

1. Should the hero-stats numbers be live or marketing-static?
2. Where should each "เรียนรู้เพิ่มเติม" service-card link route?
3. Newsletter signup — which provider?
4. The "TP" coin shown in Wallet phone — is "TPX" the final ticker name?
5. Do we need a language switcher (Thai/English)? The page is Thai-only currently.
6. Do we need a dark-mode toggle? The current design is mixed light/dark; toggling would require
   alternate light-mode treatments for `<Hero>`, `<Wallet>`, `<Footer>`.
