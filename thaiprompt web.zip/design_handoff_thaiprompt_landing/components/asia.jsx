// Simplified world map with Asia highlighted in gold/blue
function WorldMap() {
  return (
    <svg viewBox="0 0 1000 500" preserveAspectRatio="xMidYMid meet" style={{width:'100%', height:'100%'}}>
      <defs>
        <linearGradient id="seaG" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#f0f5ff"/>
          <stop offset="1" stopColor="#dbe7ff"/>
        </linearGradient>
        <linearGradient id="continent" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#cfe0ff"/>
          <stop offset="1" stopColor="#9dc0ff"/>
        </linearGradient>
        <linearGradient id="asiaG" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#1f64ff"/>
          <stop offset="0.6" stopColor="#0b4cdb"/>
          <stop offset="1" stopColor="#082b7f"/>
        </linearGradient>
        <radialGradient id="asiaGlow" cx="0.5" cy="0.5" r="0.6">
          <stop offset="0" stopColor="#f5b423" stopOpacity="0.35"/>
          <stop offset="1" stopColor="#f5b423" stopOpacity="0"/>
        </radialGradient>
      </defs>
      <rect width="1000" height="500" fill="url(#seaG)"/>

      {/* Glow behind Asia */}
      <ellipse cx="720" cy="220" rx="240" ry="180" fill="url(#asiaGlow)"/>

      {/* North America */}
      <path d="M50 110 Q 90 70 160 65 Q 220 60 260 90 Q 280 120 270 160 Q 250 210 220 240 Q 180 270 150 260 Q 100 250 70 220 Q 40 180 50 110 Z" fill="url(#continent)" opacity="0.85"/>
      <path d="M150 70 L 180 50 L 220 55 L 230 75 Z" fill="url(#continent)" opacity="0.85"/>
      {/* Greenland */}
      <path d="M310 70 Q 350 60 360 90 Q 350 130 320 130 Q 290 110 310 70 Z" fill="url(#continent)" opacity="0.85"/>

      {/* South America */}
      <path d="M210 280 Q 250 270 270 310 Q 280 360 270 410 Q 250 450 220 460 Q 195 440 195 400 Q 200 340 210 280 Z" fill="url(#continent)" opacity="0.85"/>

      {/* Europe */}
      <path d="M460 110 Q 500 90 540 100 Q 580 110 590 140 Q 580 175 540 180 Q 500 175 470 160 Q 450 140 460 110 Z" fill="url(#continent)" opacity="0.85"/>
      <path d="M455 95 L 480 85 L 500 92 L 490 105 Z" fill="url(#continent)" opacity="0.85"/>

      {/* Africa */}
      <path d="M460 200 Q 510 190 540 220 Q 560 270 555 320 Q 540 380 510 400 Q 480 410 460 380 Q 440 330 445 270 Q 450 230 460 200 Z" fill="url(#continent)" opacity="0.85"/>

      {/* Australia */}
      <path d="M820 380 Q 870 370 900 390 Q 920 410 905 430 Q 870 445 830 440 Q 800 430 805 405 Q 810 388 820 380 Z" fill="url(#continent)" opacity="0.85"/>

      {/* ASIA — highlighted */}
      {/* Russia/Siberia top */}
      <path d="M580 90 Q 650 70 760 75 Q 850 80 920 100 Q 950 120 940 150 Q 900 175 820 175 Q 720 170 640 165 Q 590 155 580 130 Z" fill="url(#asiaG)"/>
      {/* China/Mongolia */}
      <path d="M640 165 Q 720 160 800 170 Q 850 185 845 220 Q 820 255 770 260 Q 700 260 660 245 Q 625 220 640 165 Z" fill="url(#asiaG)"/>
      {/* India */}
      <path d="M620 240 Q 660 235 680 260 Q 690 295 670 320 Q 650 335 635 320 Q 615 290 615 260 Z" fill="url(#asiaG)"/>
      {/* Middle East */}
      <path d="M540 200 Q 580 195 615 210 Q 625 240 605 260 Q 580 270 555 260 Q 530 240 540 200 Z" fill="url(#asiaG)"/>
      {/* SE Asia mainland */}
      <path d="M730 270 Q 760 270 770 295 Q 770 325 750 340 Q 730 340 720 320 Q 715 290 730 270 Z" fill="url(#asiaG)"/>
      {/* Japan */}
      <path d="M880 195 Q 895 200 895 220 Q 890 245 875 245 Q 870 225 875 205 Z" fill="url(#asiaG)"/>
      <path d="M870 250 Q 880 255 880 270 Q 870 280 862 275 Z" fill="url(#asiaG)"/>
      {/* Korea peninsula */}
      <path d="M845 200 Q 855 205 854 225 Q 845 240 838 230 Q 838 210 845 200 Z" fill="url(#asiaG)"/>
      {/* Indonesia / Philippines / island groups */}
      <ellipse cx="800" cy="335" rx="22" ry="8" fill="url(#asiaG)"/>
      <ellipse cx="830" cy="345" rx="18" ry="7" fill="url(#asiaG)"/>
      <ellipse cx="775" cy="345" rx="14" ry="6" fill="url(#asiaG)"/>
      <ellipse cx="820" cy="320" rx="10" ry="14" fill="url(#asiaG)"/>

      {/* Connection arcs from Thailand */}
      <g stroke="#f5b423" strokeWidth="1.5" fill="none" strokeDasharray="3 4" opacity="0.7">
        <path d="M725 295 Q 780 230 875 215"/>{/* TH → Japan */}
        <path d="M725 295 Q 760 245 845 215"/>{/* TH → Korea */}
        <path d="M725 295 Q 750 250 770 200"/>{/* TH → China */}
        <path d="M725 295 Q 700 320 800 335"/>{/* TH → Indo */}
        <path d="M725 295 Q 760 320 820 320"/>{/* TH → Philippines */}
        <path d="M725 295 Q 690 280 660 270"/>{/* TH → India */}
      </g>
    </svg>
  );
}
window.WorldMap = WorldMap;

function Asia() {
  const flags = [
    {em:'🇹🇭', n:'ไทย'}, {em:'🇻🇳', n:'เวียดนาม'}, {em:'🇮🇩', n:'อินโดนีเซีย'},
    {em:'🇵🇭', n:'ฟิลิปปินส์'}, {em:'🇲🇾', n:'มาเลเซีย'}, {em:'🇸🇬', n:'สิงคโปร์'},
    {em:'🇱🇦', n:'ลาว'}, {em:'🇲🇲', n:'เมียนมา'}, {em:'🇰🇭', n:'กัมพูชา'},
    {em:'🇨🇳', n:'จีน'}, {em:'🇰🇷', n:'เกาหลี'}, {em:'🇯🇵', n:'ญี่ปุ่น'},
  ];
  // Pin coordinates calibrated for the WorldMap viewBox proportions
  const pins = [
    {top:'59%', left:'72.5%', gold:true, label:'TH'},
    {top:'56%', left:'77%', label:'VN'},
    {top:'68%', left:'80%', label:'ID'},
    {top:'62%', left:'82%', label:'PH'},
    {top:'66%', left:'77.5%', label:'MY'},
    {top:'66%', left:'78%', label:'SG'},
    {top:'56%', left:'74%', label:'LA'},
    {top:'58%', left:'70%', label:'MM'},
    {top:'60%', left:'74.5%', label:'KH'},
    {top:'42%', left:'77%', label:'CN'},
    {top:'42%', left:'84.5%', label:'KR'},
    {top:'42%', left:'88%', label:'JP'},
  ];
  return (
    <section id="asia" className="asia fade-top-light fade-bottom-light">
      <div className="container asia-grid">
        <div>
          <div className="eyebrow">เครือข่ายเอเชีย</div>
          <h2 style={{fontFamily:'Prompt', fontSize:'clamp(28px,3.5vw,42px)', fontWeight:800, letterSpacing:'-.02em', lineHeight:1.1, margin:'12px 0 16px'}}>
            เพื่อคนไทย <span className="grad">เพื่อเอเชีย</span><br/>เพื่ออนาคตที่ดีกว่า
          </h2>
          <p style={{color:'var(--ink-3)', fontSize:17, lineHeight:1.7, margin:0}}>
            เริ่มจากประเทศไทย ขยายต่อเนื่องไปยัง 10+ ประเทศในเอเชีย
            สร้างเศรษฐกิจดิจิทัลร่วมกัน ที่ทุกคนได้ประโยชน์อย่างเป็นธรรม
          </p>

          <div className="asia-flags">
            {flags.map((f, i) => (
              <span key={i} className="flag-pill"><span className="em">{f.em}</span> {f.n}</span>
            ))}
          </div>

          <div style={{display:'flex', gap:12}}>
            <button className="btn btn-primary">เป็นพาร์ทเนอร์กับเรา <Ico.arrow style={{width:14,height:14}}/></button>
          </div>
        </div>

        <div className="asia-map">
          <WorldMap/>
          {pins.map((p, i) => (
            <div key={i} className={"map-pin" + (p.gold ? ' gold' : '')}
                 style={{top: p.top, left: p.left, animationDelay: `${i*0.18}s`}}/>
          ))}
        </div>
      </div>
    </section>
  );
}
window.Asia = Asia;
