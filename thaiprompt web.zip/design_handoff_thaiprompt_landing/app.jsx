function App() {
  React.useEffect(() => {
    const obs = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add('in'); });
    }, { threshold: 0.1 });
    document.querySelectorAll('.reveal').forEach(el => obs.observe(el));
    return () => obs.disconnect();
  }, []);

  return (
    <>
      <Nav/>
      {/* Slide 1: fullscreen, no animation, no text */}
      <ImgSlide image="assets/slide-top.png" fade="dark" focal="center 35%" fullscreen animate={false}/>
      <Hero/>
      <Ticker/>
      <Services/>
      <ImgSlide image="assets/slide-temple.png" fade="dark" focal="center 40%"/>
      <Wallet/>
      <HowItWorks/>
      <ImgSlide image="assets/slide-flow.png" fade="light" focal="center 35%"/>
      <Asia/>
      <CTA/>
      <Footer/>
    </>
  );
}
ReactDOM.createRoot(document.getElementById('app')).render(<App/>);
