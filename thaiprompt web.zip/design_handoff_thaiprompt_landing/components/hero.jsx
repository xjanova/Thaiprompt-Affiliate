function Hero() {
  return (
    <section className="hero">
      <div className="container hero-inner">
        <div>
          <div className="hero-eyebrow">
            <span className="dot"></span>
            <span>แพลตฟอร์มคนไทย • เพื่อคนไทย • เพื่อเอเชีย</span>
          </div>

          <h1>
            <span className="gold">ไทยพร๊อมท์</span> แพลตฟอร์ม<br/>
            <span className="blue">เพื่อชีวิตที่ดีกว่า</span>
          </h1>

          <p className="hero-sub">
            รวมทุกโซลูชันในที่เดียว — Rider &amp; E-commerce, ตลาดสด, AI Management,
            กระเป๋าเงินดิจิทัล และระบบปันผลที่โปร่งใสด้วย Blockchain ของเราเอง
          </p>

          <div className="hero-pillars">
            <span className="pillar-chip"><Ico.spark/> โปร่งใส</span>
            <span className="pillar-chip"><Ico.spark/> ยุติธรรม</span>
            <span className="pillar-chip"><Ico.spark/> เติบโตไปด้วยกัน</span>
            <span className="pillar-chip"><Ico.spark/> ยั่งยืน</span>
          </div>

          <div className="hero-cta">
            <button className="btn btn-gold">
              เริ่มต้นใช้งานฟรี <Ico.arrow style={{width:16,height:16}}/>
            </button>
            <button className="btn btn-outline-white">
              ดูวิธีการทำงาน
            </button>
          </div>

          <div className="hero-meta">
            <div><strong>10+</strong> ประเทศในเอเชีย</div>
            <div><strong>50K+</strong> ผู้ใช้งาน</div>
            <div><strong>24/7</strong> ตลอดเวลา</div>
          </div>
        </div>

        <div className="hero-visual">
          <div className="hero-card">
            <div className="hero-card-bg"></div>
            <div className="hero-badge-tl">
              <Ico.star style={{width:14,height:14}}/> แพลตฟอร์มคนไทย เพื่อคนไทย
            </div>
            <div className="hero-badge-br">
              โปร่งใส · ตรวจสอบได้ด้วย Blockchain
            </div>
          </div>

          <div className="hero-floats">
            <div className="float-card float-1">
              <div className="ic"><Ico.rider style={{width:18,height:18}}/></div>
              <div>
                <div className="lbl">ออเดอร์วันนี้</div>
                <div className="val">+2,481 <span style={{color:'#22c55e',fontSize:12}}>↑12%</span></div>
              </div>
            </div>
            <div className="float-card float-2">
              <div className="ic" style={{background:'linear-gradient(135deg,#f5b423,#a86c0d)'}}>
                <Ico.wallet style={{width:18,height:18}}/>
              </div>
              <div>
                <div className="lbl">ปันผลรายสัปดาห์</div>
                <div className="val">฿ 84,250</div>
              </div>
            </div>
            <div className="float-card float-3">
              <div className="ic" style={{background:'linear-gradient(135deg,#38d3ee,#0b4cdb)'}}>
                <Ico.chain style={{width:18,height:18}}/>
              </div>
              <div>
                <div className="lbl">ธุรกรรมบนเชน</div>
                <div className="val">1.2M+ TX</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container">
        <div className="hero-stats">
          <div>
            <div className="ic-wrap"><Ico.users style={{width:22,height:22}}/></div>
            <div>
              <div className="num">50K+</div>
              <div className="lbl">ผู้ใช้งานทั่วเอเชีย</div>
            </div>
          </div>
          <div>
            <div className="ic-wrap"><Ico.cart style={{width:22,height:22}}/></div>
            <div>
              <div className="num">2.4M+</div>
              <div className="lbl">ออเดอร์ที่จัดส่ง</div>
            </div>
          </div>
          <div>
            <div className="ic-wrap"><Ico.chain style={{width:22,height:22}}/></div>
            <div>
              <div className="num">99.9%</div>
              <div className="lbl">ความเสถียรของเครือข่าย</div>
            </div>
          </div>
          <div>
            <div className="ic-wrap"><Ico.globe style={{width:22,height:22}}/></div>
            <div>
              <div className="num">10+</div>
              <div className="lbl">ประเทศ ขยายต่อเนื่อง</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
window.Hero = Hero;
