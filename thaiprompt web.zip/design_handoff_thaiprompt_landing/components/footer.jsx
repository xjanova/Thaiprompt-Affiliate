function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-grid">
          <div>
            <div className="brand" style={{marginBottom:18}}>
              <div className="brand-mark">TP</div>
              <div className="brand-text">
                <strong style={{color:'#fff'}}>ThaiPrompt <span style={{color:'var(--gold-400)'}}>ไทยพร๊อมท์</span></strong>
                <span style={{color:'rgba(255,255,255,.5)'}}>POS · Blockchain · AI Management</span>
              </div>
            </div>
            <p style={{fontSize:14, color:'rgba(255,255,255,.55)', lineHeight:1.7, margin:0, maxWidth:360}}>
              แพลตฟอร์มคนไทย เพื่อคนไทยและเอเชีย โปร่งใส ยุติธรรม เติบโตไปด้วยกัน อย่างยั่งยืน
            </p>
            <div className="footer-social" style={{marginTop:20}}>
              <a href="#" aria-label="Facebook"><svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M9 8h-3v4h3v12h5V12h3.6l.4-4H14V6.3c0-1 .2-1.3 1.2-1.3H18V0h-3.8C10.6 0 9 1.6 9 4.6V8z"/></svg></a>
              <a href="#" aria-label="LINE"><svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M19.4 10.5c0-3.4-3.4-6.1-7.5-6.1S4.4 7.1 4.4 10.5c0 3 2.7 5.6 6.4 6 .3 0 .6.2.7.5.1.2 0 .6 0 .8 0 0-.1.7-.1.8-.1.2-.2 1 .9.6 1-.4 5.6-3.3 7.7-5.7 1.4-1.6 2-3.3 2-5z"/></svg></a>
              <a href="#" aria-label="X"><svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M18.9 2H22l-7.5 8.6L23.3 22h-7l-5.5-7.2L4.5 22H1.4l8-9.2L1 2h7.2l5 6.6L18.9 2zm-1.2 18h1.9L7.4 4H5.4l12.3 16z"/></svg></a>
              <a href="#" aria-label="YouTube"><svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M23 7.5a3 3 0 0 0-2-2C19 5 12 5 12 5s-7 0-9 .5a3 3 0 0 0-2 2C.5 9.5.5 12 .5 12s0 2.5.5 4.5a3 3 0 0 0 2 2c2 .5 9 .5 9 .5s7 0 9-.5a3 3 0 0 0 2-2c.5-2 .5-4.5.5-4.5s0-2.5-.5-4.5zM10 16V8l6 4-6 4z"/></svg></a>
            </div>
          </div>
          <div>
            <h5>บริการ</h5>
            <ul>
              <li><a href="#">Rider &amp; Delivery</a></li>
              <li><a href="#">ตลาดสด</a></li>
              <li><a href="#">AI Management</a></li>
              <li><a href="#">ThaiPrompt Wallet</a></li>
              <li><a href="#">ระบบปันผล</a></li>
            </ul>
          </div>
          <div>
            <h5>นักพัฒนา</h5>
            <ul>
              <li><a href="#">Whitepaper</a></li>
              <li><a href="#">API Documentation</a></li>
              <li><a href="#">Block Explorer</a></li>
              <li><a href="#">Smart Contract</a></li>
            </ul>
          </div>
          <div>
            <h5>เกี่ยวกับเรา</h5>
            <ul>
              <li><a href="#">เกี่ยวกับ ThaiPrompt</a></li>
              <li><a href="#">ร่วมงานกับเรา</a></li>
              <li><a href="#">ติดต่อ</a></li>
              <li><a href="#">ข้อตกลงการใช้งาน</a></li>
              <li><a href="#">นโยบายความเป็นส่วนตัว</a></li>
            </ul>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© 2026 ThaiPrompt. ไทยพร๊อมท์ — แพลตฟอร์มคนไทย เพื่อคนไทยและเอเชีย</span>
          <span>www.thaiprompt.com</span>
        </div>
      </div>
    </footer>
  );
}
window.Footer = Footer;
