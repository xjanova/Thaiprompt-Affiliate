function HowItWorks() {
  const steps = [
    { n: '1', t: 'สมัครสมาชิก', d: 'สร้างบัญชีฟรีในไม่กี่นาที ยืนยันตัวตนตามมาตรฐาน KYC' },
    { n: '2', t: 'เชื่อมต่อบริการ', d: 'เลือกใช้ Rider, ตลาดสด, Wallet หรือเป็นพาร์ทเนอร์ร้านค้า' },
    { n: '3', t: 'เริ่มใช้งานทันที', d: 'ซื้อ ขาย โอน ส่งของ จัดการร้าน ผ่านแพลตฟอร์มเดียว' },
    { n: '4', t: 'รับปันผล & เติบโต', d: 'ส่วนแบ่งจากเครือข่าย กระจายอัตโนมัติบนเชน ทุกสัปดาห์' },
  ];
  return (
    <section id="how" className="how fade-top-light fade-bottom-light">
      <div className="container">
        <div className="sec-head">
          <div className="eyebrow">วิธีใช้งาน</div>
          <h2>เริ่มต้น <span className="grad">ใน 4 ขั้นตอน</span></h2>
          <p>ออกแบบให้ทุกคนใช้งานได้ ไม่ว่าจะเป็นพ่อค้าแม่ค้า ไรเดอร์ ผู้บริโภค หรือนักพัฒนา</p>
        </div>

        <div className="how-track">
          {steps.map((s, i) => (
            <div key={i} className="how-step">
              <div className="num">{s.n}</div>
              <h4>{s.t}</h4>
              <p>{s.d}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
window.HowItWorks = HowItWorks;
