function Wallet() {
  return (
    <section id="wallet" className="wallet-section fade-bottom-dark">
      <div className="container wallet-grid">
        <div>
          <div className="eyebrow" style={{color:'#ffe28a'}}>ThaiPrompt Wallet</div>
          <h2>กระเป๋าเงินดิจิทัล <span className="gold">ปลอดภัย โปร่งใส</span></h2>
          <p>
            จัดการเงิน ปันผล และเหรียญ TPX ได้จากแอปเดียว
            ทุกธุรกรรมบันทึกบน Blockchain ของเรา ตรวจสอบได้ทุกขั้นตอน
            ค่าธรรมเนียมต่ำ ใช้ได้ทั่วเอเชีย
          </p>

          <div className="wallet-feat-grid">
            <div className="wallet-feat">
              <div className="ic"><Ico.shield style={{width:18,height:18}}/></div>
              <h4>เข้ารหัสระดับธนาคาร</h4>
              <p>ระบบ multi-signature และ cold storage ปกป้องสินทรัพย์ของคุณ</p>
            </div>
            <div className="wallet-feat">
              <div className="ic"><Ico.bolt style={{width:18,height:18}}/></div>
              <h4>โอนทันที 24/7</h4>
              <p>ยืนยันธุรกรรมในไม่กี่วินาที รองรับการใช้งานข้ามประเทศ</p>
            </div>
            <div className="wallet-feat">
              <div className="ic"><Ico.dividend style={{width:18,height:18}}/></div>
              <h4>รับปันผลอัตโนมัติ</h4>
              <p>Smart contract กระจายผลประโยชน์ทุกสัปดาห์ ไร้คนกลาง</p>
            </div>
            <div className="wallet-feat">
              <div className="ic"><Ico.globe style={{width:18,height:18}}/></div>
              <h4>ใช้ได้ทั่วเอเชีย</h4>
              <p>รองรับหลายสกุลเงิน เชื่อมต่อร้านค้าและบริการในเครือข่าย</p>
            </div>
          </div>

          <div style={{display:'flex', gap:12, flexWrap:'wrap'}}>
            <button className="btn btn-gold">เปิดกระเป๋า TPX <Ico.arrow style={{width:14,height:14}}/></button>
            <button className="btn btn-outline-white">ดู Whitepaper</button>
          </div>
        </div>

        <div className="phone-mock">
          <div className="phone-orbit"></div>
          <div className="coin c1">฿</div>
          <div className="coin c2">TP</div>
          <div className="coin c3">$</div>

          <div className="phone">
            <div className="phone-notch"></div>
            <div className="phone-screen">
              <div className="phone-head">
                <div className="h1">สวัสดี, คุณสมชาย</div>
                <div className="h2">Live</div>
              </div>

              <div className="balance-card">
                <div className="lbl">ยอดคงเหลือทั้งหมด</div>
                <div className="val">฿ 128,540<small>.25</small></div>
                <div className="pct">↑ +5.2% สัปดาห์นี้</div>
              </div>

              <div className="phone-actions">
                <button><Ico.send style={{width:16,height:16}}/> ส่ง</button>
                <button><Ico.recv style={{width:16,height:16}}/> รับ</button>
                <button><Ico.swap style={{width:16,height:16}}/> สลับ</button>
                <button><Ico.qr style={{width:16,height:16}}/> สแกน</button>
              </div>

              <div className="phone-tx">
                <div className="phone-tx-item">
                  <div className="ic"><Ico.dividend style={{width:14,height:14}}/></div>
                  <div className="meta"><b>ปันผลรายสัปดาห์</b><span>วันนี้ 09:00</span></div>
                  <div className="amt up">+฿ 1,840</div>
                </div>
                <div className="phone-tx-item">
                  <div className="ic"><Ico.cart style={{width:14,height:14}}/></div>
                  <div className="meta"><b>ตลาดสด รังสิต</b><span>เมื่อวาน 16:24</span></div>
                  <div className="amt dn">-฿ 285</div>
                </div>
                <div className="phone-tx-item">
                  <div className="ic"><Ico.chain style={{width:14,height:14}}/></div>
                  <div className="meta"><b>Stake TPX</b><span>27 เม.ย. 2569</span></div>
                  <div className="amt up">+12.4 TPX</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
window.Wallet = Wallet;
